from django.apps import AppConfig


class ElearnConfig(AppConfig):
    name = 'elearn'
